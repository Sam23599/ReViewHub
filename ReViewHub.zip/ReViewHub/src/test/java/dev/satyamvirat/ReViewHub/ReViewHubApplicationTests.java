package dev.satyamvirat.ReViewHub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReViewHubApplicationTests {

	@Test
	void contextLoads() {
	}

}
